"""Manual SDK build for environments without Gradle/JDK javac.
Usage: python3 scripts/build_android.py SDK ECJ_JAR KEYSTORE PASSWORD_FILE OUTPUT_DIR
Signing inputs are kept outside the repository. Uses original alias 'ourbudget'.
"""
from pathlib import Path
import subprocess,sys,zipfile,shutil,re,json
root=Path(__file__).resolve().parents[1]
sdk,ecj,key,password,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
tools=sdk/'build-tools/35.0.0';android=sdk/'platforms/android-35/android.jar'
source=root/'android/app/src/main'
site=re.search(r'^SITE_URL=(.+)$',(root/'android/gradle.properties').read_text(),re.M).group(1)
if not site.startswith('https://') or not site.endswith('/'):raise ValueError('Set the HTTPS site URL first')
out.mkdir(parents=True,exist_ok=True)
for folder in ['classes','dex','gen']: (out/folder).mkdir(exist_ok=True)
manifest=(source/'AndroidManifest.xml').read_text().replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">','<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.ourbudget.personal" android:versionCode="2" android:versionName="2.0"><uses-sdk android:minSdkVersion="26" android:targetSdkVersion="35"/>')
(out/'AndroidManifest.xml').write_text(manifest)
(out/'BuildConfig.java').write_text('package com.ourbudget.personal; public final class BuildConfig { public static final String SITE_URL = '+json.dumps(site)+'; }')
def run(*args):subprocess.run(list(map(str,args)),check=True)
run(tools/'aapt2','compile','--dir',source/'res','-o',out/'res.zip')
run(tools/'aapt2','link','-o',out/'unsigned.apk','-I',android,'--manifest',out/'AndroidManifest.xml','--java',out/'gen',out/'res.zip')
run('java','-jar',ecj,'-source','8','-target','8','-classpath',android,'-d',out/'classes',*list((source/'java').rglob('*.java')),*list((out/'gen').rglob('*.java')),out/'BuildConfig.java')
with zipfile.ZipFile(out/'classes.jar','w') as z:
 for p in (out/'classes').rglob('*.class'):z.write(p,str(p.relative_to(out/'classes')))
run(tools/'d8','--min-api','26','--lib',android,'--output',out/'dex',out/'classes.jar')
with zipfile.ZipFile(out/'unsigned.apk','a') as z:
 for p in (out/'dex').glob('*.dex'):z.write(p,p.name)
run(tools/'zipalign','-f','4',out/'unsigned.apk',out/'aligned.apk')
run(tools/'apksigner','sign','--ks',key,'--ks-pass','file:'+str(password),'--ks-key-alias','ourbudget','--out',out/'PocketNorth.apk',out/'aligned.apk')
run(tools/'apksigner','verify','--verbose',out/'PocketNorth.apk')
run(tools/'aapt2','dump','badging',out/'PocketNorth.apk')
