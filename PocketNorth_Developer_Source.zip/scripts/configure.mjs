import {writeFile} from 'node:fs/promises';
const {SUPABASE_URL:supabaseUrl,SUPABASE_PUBLISHABLE_KEY:supabaseKey,SITE_URL:siteUrl}=process.env;
if(!supabaseUrl||!supabaseKey||!siteUrl)throw Error('Set SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY and SITE_URL repository variables.');
if(new URL(supabaseUrl).protocol!=='https:'||!new URL(supabaseUrl).hostname.endsWith('.supabase.co'))throw Error('Use your HTTPS Supabase project URL.');
if(new URL(siteUrl).protocol!=='https:'||!siteUrl.endsWith('/'))throw Error('SITE_URL must use HTTPS and end in /.');
if(supabaseKey.startsWith('sb_secret_'))throw Error('Never publish a secret key.');
if(!supabaseKey.startsWith('sb_publishable_')){
 let claims;try{claims=JSON.parse(Buffer.from(supabaseKey.split('.')[1],'base64url'));}catch{throw Error('Use a public publishable or legacy anon key.');}
 if(claims.role!=='anon')throw Error('Never publish a service role key.');
}
await writeFile('web/config.js','export const config = '+JSON.stringify({supabaseUrl,supabaseKey,siteUrl,supportEmail:'',idleMinutes:15},null,2)+';\n');
