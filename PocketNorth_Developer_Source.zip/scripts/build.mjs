import {build} from 'esbuild';
import {copyFile,mkdir} from 'node:fs/promises';
await build({stdin:{contents:"export {createClient} from '@supabase/supabase-js';",resolveDir:process.cwd()},bundle:true,format:'esm',minify:true,outfile:'web/vendor/supabase.js'});
await mkdir('supabase/functions/_shared',{recursive:true});
await copyFile('web/core.js','supabase/functions/_shared/core.js');
