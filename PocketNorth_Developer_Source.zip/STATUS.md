# PocketNorth implementation checkpoint

The cloud upgrade is a release candidate, not deployed. Do not use it with real bank data until the live release checks in README.md are complete.

Implemented source:
- Responsive web interface: sign-up/sign-in, mandatory authenticator verification, categories, transaction review, CSV imports, duplicate detection, budgets, and clickable spending insights.
- Supabase database migration with owner isolation and MFA checks.
- Bundled Supabase browser SDK; public configuration remains blank.
- Server-side Plaid Hosted Link, encrypted tokens, incremental sync, reconnect/disconnect, account deletion, and consent-based aggregate AI review.
- GitHub Pages workflow and Android HTTPS wrapper source.

Verified locally:
- Five import/classification test groups, including the $30 boundary, renamed rule categories, stable IDs, conflicting IDs, repeated no-ID imports, and exclusions.
- PostgreSQL migration, owner isolation, MFA gates, restricted columns, atomic imports, category merging, sync cursor conflicts, pending reconciliation, and account deletion.
- Desktop/phone browser render, category addition, transaction editing, duplicate import, and no page exceptions or horizontal page overflow.
- JavaScript syntax and backend TypeScript transpilation.

Still required before release:
- Live Supabase Auth, realtime, and Plaid Sandbox end-to-end checks; optional OpenAI API check.
- Android compilation and physical-device testing.
- Connect the intended GitHub repository and Supabase project, configure authentication and server secrets, and deploy.
- Build/sign the updated Android APK against the actual HTTPS site URL.

GitHub and Supabase installation was confirmed by the user, but their callable tools have not surfaced in the active session. No repository, live project, or bank connection has been modified.

The original working budget HTML and Android APK remain separate. This source does not contain the original personal transactions or Android signing credentials.
