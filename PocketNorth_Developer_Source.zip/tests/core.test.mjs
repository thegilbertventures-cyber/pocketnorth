import test from 'node:test';
import assert from 'node:assert/strict';
import {classify,parseCSV,prepareImport,dateISO,totals} from '../web/core.js';
const categories=[{id:'fuel',name:'Vehicle fuel',system_key:'fuel'},{id:'gas',name:'Quick stops',system_key:'gas_station'},{id:'review',name:'Needs review',system_key:'review'}];
const row=(id,amount='-30.01')=>({'posting date':'09/01/2026',amount,description:'Maverik','transaction id':id});
test('gas boundary, merchant rule priority, positive refund',()=>{
 assert.equal(classify('Maverik',-3001).category,'Fuel');assert.equal(classify('Shell',-3000).category,'Gas Station');
 assert.equal(classify('Shell',-3001,'',[{merchant:'shell',category:'Coffee',kind:'expense'}]).category,'Fuel');
 assert.notEqual(classify('Maverik',4000).category,'Fuel');
});
test('CSV quoting and invalid input',()=>{
 assert.equal(parseCSV('Posting Date,Amount,Description\r\n09/01/2026,-32.01,"Shop, One"')[0].description,'Shop, One');
 assert.throws(()=>parseCSV('Posting Date,Amount,Description\n2026-09-01,-12,"open'));
 assert.throws(()=>dateISO('02/30/2026'));
});
test('stable IDs, conflict rollback preview, renamed system category',async()=>{
 const first=await prepareImport([row('a'),row('a')],'acct',categories,[]);
 assert.equal(first.added.length,1);assert.equal(first.skipped,1);assert.equal(first.added[0].category_id,'fuel');
 const second=await prepareImport([row('a')],'acct',categories,first.added);assert.equal(second.added.length,0);
 await assert.rejects(()=>prepareImport([row('a','-35')],'acct',categories,first.added),/conflict/);
});
test('identical legitimate purchases retained; repeat no-ID file idempotent',async()=>{
 const first=await prepareImport([row(''),row('')],'acct',categories,[]);assert.equal(first.added.length,2);assert.equal(first.added[1].reviewed,false);
 const second=await prepareImport([row(''),row('')],'acct',categories,first.added);assert.equal(second.skipped,2);
});
test('different IDs are flagged and excluded/pending/removed never counted',async()=>{
 const first=await prepareImport([row('a'),row('b')],'acct',categories,[]);assert.equal(first.added.length,2);assert.equal(first.added[1].reviewed,false);
 assert.equal(totals([...first.added,{...first.added[0],excluded:true},{...first.added[0],pending:true},{...first.added[0],removed:true}]).spend,6002);
});
