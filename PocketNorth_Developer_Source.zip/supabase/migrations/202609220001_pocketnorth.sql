-- PocketNorth: mandatory MFA and per-user isolation. No financial data is public.
create extension if not exists pgcrypto;
create table public.categories(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,name text not null check(length(name) between 1 and 80),system_key text,archived boolean not null default false,created_at timestamptz not null default now(),unique(user_id,id),unique(user_id,name),unique(user_id,system_key));
create table public.accounts(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,name text not null check(length(name) between 1 and 100),provider_id text,bank_item_id text,mask text,created_at timestamptz not null default now(),unique(user_id,id),unique(user_id,provider_id));
create table public.transactions(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,account_id uuid not null,category_id uuid not null,date date not null,amount_cents bigint not null check(abs(amount_cents)<=1000000000000),description text not null check(length(description)<=500),kind text not null check(kind in('expense','income','transfer','savings','unresolved')),source text not null check(source in('csv','plaid')),external_id text not null, pending_id text,pending boolean not null default false,removed boolean not null default false,excluded boolean not null default false,reviewed boolean not null default false,manual_category boolean not null default false,review_reason text not null default '',note text not null default '' check(length(note)<=1000),updated_at timestamptz not null default now(),foreign key(user_id,account_id) references public.accounts(user_id,id),foreign key(user_id,category_id) references public.categories(user_id,id),unique(user_id,account_id,source,external_id));
create index transactions_user_date on public.transactions(user_id,date);
create table public.budgets(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,month text not null check(month~'^\d{4}-(0[1-9]|1[0-2])$'),category_id uuid not null,amount_cents bigint not null check(amount_cents between 0 and 1000000000000),updated_at timestamptz not null default now(),foreign key(user_id,category_id) references public.categories(user_id,id),unique(user_id,month,category_id));
create table public.merchant_rules(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,merchant text not null check(length(merchant) between 1 and 500),category_id uuid not null,kind text not null check(kind in('expense','income','transfer','savings','unresolved')),foreign key(user_id,category_id) references public.categories(user_id,id),unique(user_id,merchant));
create table public.bank_connections(item_id text primary key,user_id uuid not null references auth.users on delete cascade,institution text not null default 'Connected bank',status text not null default 'connected',last_synced timestamptz,created_at timestamptz not null default now());
-- Server-only ciphertext. No anonymous/authenticated access, even with a guessed REST path.
create table public.bank_secrets(item_id text primary key references public.bank_connections on delete cascade,user_id uuid not null references auth.users on delete cascade,ciphertext text not null,cursor text,lock_until timestamptz not null default '-infinity',lock_id uuid);
create table public.link_sessions(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,ciphertext text not null,item_id text,completed boolean not null default false,expires_at timestamptz not null,created_at timestamptz not null default now());
create table public.rate_limits(user_id uuid not null references auth.users on delete cascade,action text not null,window_start timestamptz not null,count integer not null,primary key(user_id,action,window_start));
create table public.ai_reviews(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users on delete cascade,month text not null,payload jsonb not null,created_at timestamptz not null default now());
create function public.touch_updated_at() returns trigger language plpgsql set search_path='' as $$begin new.updated_at=now();return new;end$$;
create trigger touch_transactions before update on public.transactions for each row execute function public.touch_updated_at();
create trigger touch_budgets before update on public.budgets for each row execute function public.touch_updated_at();
do $$ declare t text;begin
 foreach t in array array['categories','accounts','transactions','budgets','merchant_rules','bank_connections','bank_secrets','link_sessions','rate_limits','ai_reviews'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from anon, authenticated',t);
 execute format('grant all on public.%I to service_role',t);
 end loop;
 foreach t in array array['categories','accounts','transactions','budgets','merchant_rules','bank_connections','ai_reviews'] loop
 execute format('grant select on public.%I to authenticated',t);
 execute format('create policy own_mfa_read on public.%I for select to authenticated using(user_id=(select auth.uid()) and (select auth.jwt()->>''aal'')=''aal2'')',t);
 end loop;
 foreach t in array array['categories','accounts','budgets','merchant_rules'] loop
 execute format('grant insert on public.%I to authenticated',t);
 execute format('create policy own_mfa_insert on public.%I for insert to authenticated with check(user_id=(select auth.uid()) and (select auth.jwt()->>''aal'')=''aal2'')',t);
 end loop;
 foreach t in array array['categories','transactions','budgets','merchant_rules'] loop
 execute format('create policy own_mfa_update on public.%I for update to authenticated using(user_id=(select auth.uid()) and (select auth.jwt()->>''aal'')=''aal2'') with check(user_id=(select auth.uid()) and (select auth.jwt()->>''aal'')=''aal2'')',t);
 end loop;
end$$;
grant update(name,archived) on public.categories to authenticated;
grant update(category_id,kind,note,excluded,reviewed,manual_category) on public.transactions to authenticated;
grant update(amount_cents) on public.budgets to authenticated;
grant update(category_id,kind) on public.merchant_rules to authenticated;
grant delete on public.merchant_rules to authenticated;
create policy own_mfa_delete on public.merchant_rules for delete to authenticated using(user_id=auth.uid() and auth.jwt()->>'aal'='aal2');
create function public.require_mfa() returns uuid language plpgsql set search_path='' as $$begin if auth.uid() is null or auth.jwt()->>'aal' is distinct from 'aal2' then raise exception 'MFA required';end if;return auth.uid();end$$;
create function public.initialize_budget() returns void language plpgsql security definer set search_path='' as $$declare u uuid:=public.require_mfa();n text;begin
 foreach n in array array['Fuel','Gas Station','Groceries','Coffee','Restaurants & Dining','Shopping','Rent','Utilities','Internet','Phone','Insurance','Healthcare & Pharmacy','Loans','Credit Card Payments','Dues and Subscriptions','Entertainment','Savings','Education','Vehicle','Vacation','Charity','Needs review'] loop
 insert into public.categories(user_id,name,system_key) values(u,n,case when n='Needs review' then 'review' when n='Fuel' then 'fuel' when n='Gas Station' then 'gas_station' else null end) on conflict do nothing;
 end loop;end$$;
create function public.delete_category(p_id uuid,p_replacement uuid default null) returns void language plpgsql security definer set search_path='' as $$declare u uuid:=public.require_mfa();c public.categories;begin
 select * into c from public.categories where id=p_id and user_id=u for update;if not found then raise exception 'Category not found';end if;
 if c.system_key is not null then raise exception 'Rule categories can be renamed but cannot be deleted';end if;
 if p_replacement is not null and (p_replacement=p_id or not exists(select 1 from public.categories where id=p_replacement and user_id=u and not archived)) then raise exception 'Choose an active replacement category';end if;
 if exists(select 1 from public.transactions where category_id=p_id and user_id=u) or exists(select 1 from public.budgets where category_id=p_id and user_id=u) or exists(select 1 from public.merchant_rules where category_id=p_id and user_id=u) then
 if p_replacement is null then raise exception 'Replacement category required';end if;
 update public.transactions set category_id=p_replacement where category_id=p_id and user_id=u;
 update public.merchant_rules set category_id=p_replacement where category_id=p_id and user_id=u;
 insert into public.budgets(user_id,month,category_id,amount_cents) select user_id,month,p_replacement,amount_cents from public.budgets where category_id=p_id and user_id=u on conflict(user_id,month,category_id) do update set amount_cents=public.budgets.amount_cents+excluded.amount_cents;
 delete from public.budgets where category_id=p_id and user_id=u;
 end if;delete from public.categories where id=p_id and user_id=u;end$$;
create function public.import_csv(p_account uuid,p_rows jsonb) returns jsonb language plpgsql security definer set search_path='' as $$declare u uuid:=public.require_mfa();r jsonb;added integer:=0;skipped integer:=0;n integer;begin
 if not exists(select 1 from public.accounts where id=p_account and user_id=u) then raise exception 'Account not found';end if;
 if jsonb_typeof(p_rows)<>'array' or jsonb_array_length(p_rows)>2000 then raise exception 'Import a maximum of 2,000 rows at a time';end if;
 for r in select * from jsonb_array_elements(p_rows) loop
 if not exists(select 1 from public.categories where id=(r->>'category_id')::uuid and user_id=u and not archived) then raise exception 'Invalid category';end if;
 if exists(select 1 from public.transactions where user_id=u and account_id=p_account and source='csv' and external_id=r->>'external_id' and (date<>(r->>'date')::date or amount_cents<>(r->>'amount_cents')::bigint)) then raise exception 'Transaction ID conflict; import rolled back';end if;
 insert into public.transactions(user_id,account_id,category_id,date,amount_cents,description,kind,source,external_id,reviewed,review_reason,note,excluded,manual_category)
 values(u,p_account,(r->>'category_id')::uuid,(r->>'date')::date,(r->>'amount_cents')::bigint,r->>'description',r->>'kind','csv',r->>'external_id',coalesce((r->>'reviewed')::boolean,false),coalesce(r->>'review_reason',''),coalesce(r->>'note',''),coalesce((r->>'excluded')::boolean,false),coalesce((r->>'manual_category')::boolean,false)) on conflict(user_id,account_id,source,external_id) do nothing;
 get diagnostics n=row_count;added:=added+n;skipped:=skipped+1-n;
 end loop;return jsonb_build_object('added',added,'skipped',skipped);end$$;
create function public.rate_limit(p_user uuid,p_action text,p_limit int,p_seconds int) returns boolean language plpgsql security definer set search_path='' as $$declare w timestamptz:=to_timestamp(floor(extract(epoch from now())/p_seconds)*p_seconds);n int;begin
 insert into public.rate_limits(user_id,action,window_start,count) values(p_user,p_action,w,1) on conflict(user_id,action,window_start) do update set count=public.rate_limits.count+1 returning count into n;return n<=p_limit;end$$;
create function public.claim_sync(p_item text,p_lock uuid) returns boolean language sql security definer set search_path='' as $$with x as(update public.bank_secrets set lock_until=now()+interval '4 minutes',lock_id=p_lock where item_id=p_item and lock_until<now() returning 1) select exists(select 1 from x)$$;
create function public.apply_sync(p_item text,p_lock uuid,p_old_cursor text,p_cursor text,p_rows jsonb,p_removed jsonb) returns void language plpgsql security definer set search_path='' as $$declare u uuid;r jsonb;c public.transactions;begin
 select user_id into u from public.bank_secrets where item_id=p_item and lock_id=p_lock and cursor is not distinct from p_old_cursor for update;if u is null then raise exception 'Sync conflict; retry from saved cursor';end if;
 for r in select * from jsonb_array_elements(p_rows) loop
 if not exists(select 1 from public.accounts where id=(r->>'account_id')::uuid and user_id=u and bank_item_id=p_item) then raise exception 'Invalid sync account';end if;
 select * into c from public.transactions where user_id=u and source='plaid' and external_id=r->>'pending_id' and account_id=(r->>'account_id')::uuid;
 insert into public.transactions(user_id,account_id,category_id,date,amount_cents,description,kind,source,external_id,pending_id,pending,reviewed,review_reason,manual_category,note,excluded)
 values(u,(r->>'account_id')::uuid,case when c.manual_category then c.category_id else (r->>'category_id')::uuid end,(r->>'date')::date,(r->>'amount_cents')::bigint,r->>'description',case when c.manual_category then c.kind else r->>'kind' end,'plaid',r->>'external_id',r->>'pending_id',(r->>'pending')::boolean,case when c.manual_category then c.reviewed else (r->>'reviewed')::boolean end,coalesce(r->>'review_reason',''),coalesce(c.manual_category,false),coalesce(c.note,''),coalesce(c.excluded,false))
 on conflict(user_id,account_id,source,external_id) do update set date=excluded.date,amount_cents=excluded.amount_cents,description=excluded.description,pending=excluded.pending,removed=false,category_id=case when public.transactions.manual_category then public.transactions.category_id else excluded.category_id end,kind=case when public.transactions.manual_category then public.transactions.kind else excluded.kind end,reviewed=case when public.transactions.manual_category then public.transactions.reviewed else excluded.reviewed end,review_reason=case when public.transactions.manual_category then public.transactions.review_reason else excluded.review_reason end;
 if r->>'pending_id' is not null then update public.transactions set removed=true where user_id=u and source='plaid' and external_id=r->>'pending_id' and account_id=(r->>'account_id')::uuid;end if;
 end loop;
 update public.transactions set removed=true where user_id=u and source='plaid' and external_id in(select jsonb_array_elements_text(p_removed)) and account_id in(select id from public.accounts where user_id=u and bank_item_id=p_item);
 update public.bank_secrets set cursor=p_cursor,lock_until='-infinity',lock_id=null where item_id=p_item and lock_id=p_lock;
 update public.bank_connections set last_synced=now(),status='connected' where item_id=p_item;end$$;
-- Explicit EXECUTE privileges; security-definer functions are not public utilities.
revoke all on function public.initialize_budget(),public.delete_category(uuid,uuid),public.import_csv(uuid,jsonb),public.require_mfa() from public,anon;
grant execute on function public.initialize_budget(),public.delete_category(uuid,uuid),public.import_csv(uuid,jsonb),public.require_mfa() to authenticated;
revoke all on function public.rate_limit(uuid,text,int,int),public.claim_sync(text,uuid),public.apply_sync(text,uuid,text,text,jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.rate_limit(uuid,text,int,int),public.claim_sync(text,uuid),public.apply_sync(text,uuid,text,text,jsonb,jsonb) to service_role;
do $$declare t text;begin foreach t in array array['categories','accounts','transactions','budgets','merchant_rules','bank_connections'] loop
 if exists(select 1 from pg_publication where pubname='supabase_realtime') and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=t) then execute format('alter publication supabase_realtime add table public.%I',t);end if;end loop;end$$;
