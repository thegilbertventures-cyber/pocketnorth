package com.ourbudget.personal;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONObject;

/** Auth-per-use Keystore wrapping key protects a random, memory-only session data key. */
final class SessionVault {
    private static final String ALIAS="PocketNorth.SessionWrap.v1";
    private final MainActivity activity;
    private final SharedPreferences prefs;
    private byte[] dataKey;
    private JSONObject values=new JSONObject();
    private boolean prompting;
    SessionVault(MainActivity activity){this.activity=activity;prefs=activity.getSharedPreferences("session_vault",Context.MODE_PRIVATE);}
    synchronized boolean enabled(){return prefs.contains("wrapped");}
    synchronized boolean unlocked(){return dataKey!=null;}
    boolean available(){return Build.VERSION.SDK_INT>=30&&activity.getSystemService(BiometricManager.class).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG|BiometricManager.Authenticators.DEVICE_CREDENTIAL)==BiometricManager.BIOMETRIC_SUCCESS;}
    boolean prompting(){return prompting;}
    private static String enc(byte[] v){return Base64.encodeToString(v,Base64.NO_WRAP);}
    private static byte[] dec(String v){return Base64.decode(v,Base64.NO_WRAP);}
    synchronized void lock(){if(dataKey!=null)Arrays.fill(dataKey,(byte)0);dataKey=null;values=new JSONObject();}
    synchronized void reset(){lock();prefs.edit().clear().commit();try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);ks.deleteEntry(ALIAS);}catch(Exception ignored){}}
    synchronized String get(String key){if(dataKey==null)throw new IllegalStateException("Unlock PocketNorth first");return values.has(key)?values.optString(key,null):null;}
    synchronized void put(String key,String value){if(dataKey==null)throw new IllegalStateException("Unlock PocketNorth first");try{if(value==null)values.remove(key);else values.put(key,value);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(dataKey,"AES"));byte[] encrypted=c.doFinal(values.toString().getBytes("UTF-8"));if(!prefs.edit().putString("data",enc(encrypted)).putString("data_iv",enc(c.getIV())).commit())throw new Exception();}catch(Exception e){throw new IllegalStateException("Could not save encrypted session");}}
    void authenticate(boolean enrolling){
        if(prompting)return;
        if(!available()){activity.vaultFailed("Set up a fingerprint or screen lock in Android Settings. Biometric unlock requires Android 11 or newer.");return;}
        try{
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
            if(enrolling){KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setUserAuthenticationRequired(true).setUserAuthenticationParameters(0,KeyProperties.AUTH_BIOMETRIC_STRONG|KeyProperties.AUTH_DEVICE_CREDENTIAL).build());generator.generateKey();}
            SecretKey key=(SecretKey)ks.getKey(ALIAS,null);if(key==null)throw new Exception();
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            if(enrolling)cipher.init(Cipher.ENCRYPT_MODE,key);else cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,dec(prefs.getString("wrap_iv",""))));
            prompting=true;
            new BiometricPrompt.Builder(activity).setTitle(enrolling?"Enable PocketNorth unlock":"Unlock PocketNorth").setSubtitle("Use your fingerprint or device screen lock").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG|BiometricManager.Authenticators.DEVICE_CREDENTIAL).build().authenticate(new BiometricPrompt.CryptoObject(cipher),new CancellationSignal(),activity.getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){
                    prompting=false;
                    try{synchronized(SessionVault.this){Cipher approved=result.getCryptoObject().getCipher();if(enrolling){byte[] fresh=new byte[32];new SecureRandom().nextBytes(fresh);byte[] wrapped=approved.doFinal(fresh);if(!prefs.edit().putString("wrapped",enc(wrapped)).putString("wrap_iv",enc(approved.getIV())).commit())throw new Exception();dataKey=fresh;values=new JSONObject();}else{dataKey=approved.doFinal(dec(prefs.getString("wrapped","")));String encrypted=prefs.getString("data",null);if(encrypted!=null){Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(dataKey,"AES"),new GCMParameterSpec(128,dec(prefs.getString("data_iv",""))));values=new JSONObject(new String(c.doFinal(dec(encrypted)),"UTF-8"));}}}activity.vaultUnlocked(enrolling);}catch(Exception e){lock();activity.vaultFailed("Saved login could not be unlocked. Use Sign in again to recover.");}
                }
                @Override public void onAuthenticationError(int code,CharSequence text){prompting=false;activity.vaultFailed("Unlock canceled or unavailable. Try again, or sign in again.");}
            });
        }catch(Exception e){prompting=false;activity.vaultFailed("Saved login is unavailable. Use Sign in again to recover.");}
    }
}
