package com.ourbudget.personal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.graphics.Color;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final int PICK=41,SAVE=42;
    private final Uri site=Uri.parse(BuildConfig.SITE_URL);
    private WebView web;
    private ValueCallback<Uri[]> picker;
    private String exportText;
    private boolean saving;
    private SessionVault vault;
    private LinearLayout lockScreen;
    private TextView lockMessage;
    private volatile boolean pageTrusted;
    private boolean pageLoaded;

    private boolean trusted(Uri uri) {
        return uri!=null && "https".equals(uri.getScheme()) && site.getHost().equals(uri.getHost()) && site.getPort()==uri.getPort()
            && (site.getPath().equals(uri.getPath()) || (site.getPath()+"index.html").equals(uri.getPath()));
    }
    private boolean trustedPage() { return web!=null && web.getUrl()!=null && trusted(Uri.parse(web.getUrl())); }
    private void notice(String text) {Toast.makeText(this,text,Toast.LENGTH_LONG).show();}

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        FrameLayout root=new FrameLayout(this);web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        vault=new SessionVault(this);
        lockScreen=new LinearLayout(this);lockScreen.setOrientation(LinearLayout.VERTICAL);lockScreen.setGravity(android.view.Gravity.CENTER);lockScreen.setPadding(32,32,32,32);lockScreen.setBackgroundColor(Color.rgb(245,247,248));
        lockMessage=new TextView(this);lockMessage.setText("PocketNorth is locked");lockMessage.setTextSize(22);lockMessage.setGravity(android.view.Gravity.CENTER);lockScreen.addView(lockMessage);
        Button unlock=new Button(this);unlock.setText("Unlock PocketNorth");unlock.setOnClickListener(v->vault.authenticate(false));lockScreen.addView(unlock);
        Button reset=new Button(this);reset.setText("Sign in again");reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Clear saved login?").setMessage("Your cloud budget stays safe. Sign in with your password and authenticator again.").setPositiveButton("Sign in again",(d,w)->{vault.reset();pageTrusted=false;if(pageLoaded){web.resumeTimers();web.onResume();web.evaluateJavascript("sessionStorage.clear();location.reload()",null);}else{web.loadUrl(BuildConfig.SITE_URL);pageLoaded=true;}lockScreen.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);}).setNegativeButton("Cancel",null).show());lockScreen.addView(reset);
        root.addView(lockScreen,new FrameLayout.LayoutParams(-1,-1));lockScreen.setVisibility(vault.enabled()?View.VISIBLE:View.GONE);
        if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener((v,insets)->{Insets p=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());v.setPadding(p.left,p.top,p.right,p.bottom);return insets;});else root.setFitsSystemWindows(true);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        WebView.setWebContentsDebuggingEnabled(false);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.addJavascriptInterface(new Files(),"AndroidFiles");
        web.addJavascriptInterface(new VaultBridge(),"AndroidVault");
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){pageTrusted=trusted(Uri.parse(url));}
            @Override public void onPageFinished(WebView v,String url){pageTrusted=trusted(Uri.parse(url));}
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !trusted(r.getUrl());}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())new AlertDialog.Builder(MainActivity.this).setTitle("Cannot load PocketNorth").setMessage("Check your internet connection, then retry.").setPositiveButton("Retry",(d,w)->web.loadUrl(BuildConfig.SITE_URL)).setNegativeButton("Close",(d,w)->finish()).show();}
            // The default SSL error handler cancels. Never call proceed().
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(!trustedPage()){callback.onReceiveValue(null);return true;}
                if(picker!=null)picker.onReceiveValue(null);picker=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","application/json","text/plain","application/octet-stream","application/vnd.ms-excel"});
                try{startActivityForResult(i,PICK);}catch(Exception e){picker.onReceiveValue(null);picker=null;notice("No file picker is available.");}return true;
            }
            @Override public boolean onJsAlert(WebView v,String u,String text,JsResult r){new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("OK",(d,w)->r.confirm()).setOnCancelListener(d->r.cancel()).show();return true;}
            @Override public boolean onJsConfirm(WebView v,String u,String text,JsResult r){new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("Continue",(d,w)->r.confirm()).setNegativeButton("Cancel",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}
            @Override public boolean onJsPrompt(WebView v,String u,String text,String value,JsPromptResult r){EditText input=new EditText(MainActivity.this);input.setText(value);new AlertDialog.Builder(MainActivity.this).setMessage(text).setView(input).setPositiveButton("Confirm",(d,w)->r.confirm(input.getText().toString())).setNegativeButton("Cancel",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}
        });
        if(!vault.enabled()){web.loadUrl(BuildConfig.SITE_URL);pageLoaded=true;}else web.setVisibility(View.INVISIBLE);
    }
    public final class Files {
        @JavascriptInterface public void openExternal(String value){
            runOnUiThread(()->{if(!trustedPage()||value==null)return;Uri uri=Uri.parse(value);if(!"https".equals(uri.getScheme())||!"secure.plaid.com".equals(uri.getHost()))return;
                try{startActivity(new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE));}catch(Exception e){notice("Install a web browser to connect your bank.");}});
        }
        @JavascriptInterface public void save(String name,String text,String mime){
            if(name==null||text==null||text.length()>30*1024*1024)return;
            runOnUiThread(()->{if(!trustedPage())return;if(saving){notice("Finish the previous save first.");return;}saving=true;exportText=text;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^A-Za-z0-9._-]","_"));
                try{startActivityForResult(i,SAVE);}catch(Exception e){saving=false;exportText=null;notice("Cannot open the save dialog.");}});
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK&&picker!=null){Uri u=data==null?null:data.getData();picker.onReceiveValue(result==RESULT_OK&&u!=null&&"content".equals(u.getScheme())?new Uri[]{u}:null);picker=null;}
        if(request==SAVE){final String payload=exportText;exportText=null;
            if(result!=RESULT_OK||data==null||data.getData()==null||payload==null){saving=false;notice("Save canceled.");return;}
            final Uri uri=data.getData();new Thread(()->{String message;try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new Exception();out.write(payload.getBytes(StandardCharsets.UTF_8));message="Export saved.";}catch(Exception e){message="Save failed. Try another folder.";}final String done=message;runOnUiThread(()->{saving=false;notice(done);});}).start();
        }
    }
    public final class VaultBridge {
        @JavascriptInterface public boolean isAvailable(){return vault.available();}
        @JavascriptInterface public boolean isEnabled(){return vault.enabled();}
        @JavascriptInterface public boolean isLocked(){return vault.enabled()&&!vault.unlocked();}
        private void check(String key){if(!pageTrusted||!vault.unlocked()||key==null||!key.startsWith("sb-nsnvijabnzqqcxbuwdlk-auth-token"))throw new SecurityException("Session storage is locked");}
        @JavascriptInterface public String getItem(String key){check(key);return vault.get(key);}
        @JavascriptInterface public void setItem(String key,String value){check(key);if(value==null||value.length()>100000)throw new IllegalArgumentException();vault.put(key,value);}
        @JavascriptInterface public void removeItem(String key){check(key);vault.put(key,null);}
        @JavascriptInterface public void enable(){runOnUiThread(()->{if(trustedPage()&&!vault.enabled())vault.authenticate(true);});}
        @JavascriptInterface public void disable(){runOnUiThread(()->{if(trustedPage()&&vault.unlocked())vault.reset();});}
        @JavascriptInterface public void lock(){runOnUiThread(()->lockApp());}
    }
    void vaultUnlocked(boolean enrolled){
        web.setVisibility(View.VISIBLE);lockScreen.setVisibility(View.GONE);web.resumeTimers();web.onResume();
        if(!pageLoaded){web.loadUrl(BuildConfig.SITE_URL);pageLoaded=true;}
        else web.evaluateJavascript("window.dispatchEvent(new Event('"+(enrolled?"pocketnorth-vault-enabled":"pocketnorth-unlocked")+"'))",null);
    }
    void vaultFailed(String message){lockMessage.setText(message);notice(message);}
    private void lockApp(){if(vault==null||!vault.enabled()||vault.prompting())return;web.setVisibility(View.INVISIBLE);lockScreen.setVisibility(View.VISIBLE);lockMessage.setText("PocketNorth is locked");web.onPause();web.pauseTimers();vault.lock();}
    @Override protected void onPause(){super.onPause();if(vault!=null&&vault.enabled()&&!vault.prompting()) {web.setVisibility(View.INVISIBLE);lockScreen.setVisibility(View.VISIBLE);}}
    @Override protected void onStop(){super.onStop();lockApp();}
    @Override protected void onResume(){super.onResume();if(vault!=null&&vault.enabled()){if(!vault.unlocked())vault.authenticate(false);else{web.setVisibility(View.VISIBLE);lockScreen.setVisibility(View.GONE);}}}
    @Override public void onBackPressed(){if(vault.enabled()&&!vault.unlocked()){moveTaskToBack(true);return;}web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(d){d.close();return true}return false})()",r->{if(!"true".equals(r))moveTaskToBack(true);});}
    @Override protected void onDestroy(){if(picker!=null)picker.onReceiveValue(null);web.removeJavascriptInterface("AndroidFiles");web.removeJavascriptInterface("AndroidVault");if(vault!=null)vault.lock();web.resumeTimers();web.destroy();super.onDestroy();}
}
