package com.ourbudget.personal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final int PICK=41,SAVE=42;
    private final Uri site=Uri.parse(BuildConfig.SITE_URL);
    private WebView web;
    private ValueCallback<Uri[]> picker;
    private String exportText;
    private boolean saving;
    private long backgroundAt;

    private boolean trusted(Uri uri) {
        return uri!=null && "https".equals(uri.getScheme()) && site.getHost().equals(uri.getHost()) && site.getPort()==uri.getPort()
            && (site.getPath().equals(uri.getPath()) || (site.getPath()+"index.html").equals(uri.getPath()));
    }
    private boolean trustedPage() { return web!=null && web.getUrl()!=null && trusted(Uri.parse(web.getUrl())); }
    private void notice(String text) {Toast.makeText(this,text,Toast.LENGTH_LONG).show();}

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        FrameLayout root=new FrameLayout(this);web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        if(Build.VERSION.SDK_INT>=30)root.setOnApplyWindowInsetsListener((v,insets)->{Insets p=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());v.setPadding(p.left,p.top,p.right,p.bottom);return insets;});else root.setFitsSystemWindows(true);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        WebView.setWebContentsDebuggingEnabled(false);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.addJavascriptInterface(new Files(),"AndroidFiles");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !trusted(r.getUrl());}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())new AlertDialog.Builder(MainActivity.this).setTitle("Cannot load PocketNorth").setMessage("Check your internet connection, then retry.").setPositiveButton("Retry",(d,w)->web.loadUrl(BuildConfig.SITE_URL)).setNegativeButton("Close",(d,w)->finish()).show();}
            // The default SSL error handler cancels. Never call proceed().
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(!trustedPage()){callback.onReceiveValue(null);return true;}
                if(picker!=null)picker.onReceiveValue(null);picker=callback;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","application/json","text/plain","application/octet-stream","application/vnd.ms-excel"});
                try{startActivityForResult(i,PICK);}catch(Exception e){picker.onReceiveValue(null);picker=null;notice("No file picker is available.");}return true;
            }
            @Override public boolean onJsAlert(WebView v,String u,String text,JsResult r){new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("OK",(d,w)->r.confirm()).setOnCancelListener(d->r.cancel()).show();return true;}
            @Override public boolean onJsConfirm(WebView v,String u,String text,JsResult r){new AlertDialog.Builder(MainActivity.this).setMessage(text).setPositiveButton("Continue",(d,w)->r.confirm()).setNegativeButton("Cancel",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}
            @Override public boolean onJsPrompt(WebView v,String u,String text,String value,JsPromptResult r){EditText input=new EditText(MainActivity.this);input.setText(value);new AlertDialog.Builder(MainActivity.this).setMessage(text).setView(input).setPositiveButton("Confirm",(d,w)->r.confirm(input.getText().toString())).setNegativeButton("Cancel",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}
        });
        web.loadUrl(BuildConfig.SITE_URL);
    }
    public final class Files {
        @JavascriptInterface public void openExternal(String value){
            runOnUiThread(()->{if(!trustedPage()||value==null)return;Uri uri=Uri.parse(value);if(!"https".equals(uri.getScheme())||!"secure.plaid.com".equals(uri.getHost()))return;
                try{startActivity(new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE));}catch(Exception e){notice("Install a web browser to connect your bank.");}});
        }
        @JavascriptInterface public void save(String name,String text,String mime){
            if(name==null||text==null||text.length()>30*1024*1024)return;
            runOnUiThread(()->{if(!trustedPage())return;if(saving){notice("Finish the previous save first.");return;}saving=true;exportText=text;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,name.replaceAll("[^A-Za-z0-9._-]","_"));
                try{startActivityForResult(i,SAVE);}catch(Exception e){saving=false;exportText=null;notice("Cannot open the save dialog.");}});
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK&&picker!=null){Uri u=data==null?null:data.getData();picker.onReceiveValue(result==RESULT_OK&&u!=null&&"content".equals(u.getScheme())?new Uri[]{u}:null);picker=null;}
        if(request==SAVE){final String payload=exportText;exportText=null;
            if(result!=RESULT_OK||data==null||data.getData()==null||payload==null){saving=false;notice("Save canceled.");return;}
            final Uri uri=data.getData();new Thread(()->{String message;try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new Exception();out.write(payload.getBytes(StandardCharsets.UTF_8));message="Export saved.";}catch(Exception e){message="Save failed. Try another folder.";}final String done=message;runOnUiThread(()->{saving=false;notice(done);});}).start();
        }
    }
    @Override protected void onPause(){super.onPause();backgroundAt=System.currentTimeMillis();}
    @Override protected void onResume(){super.onResume();if(web!=null&&backgroundAt>0&&System.currentTimeMillis()-backgroundAt>15*60*1000){web.evaluateJavascript("sessionStorage.clear();location.reload()",null);}}
    @Override public void onBackPressed(){web.evaluateJavascript("(()=>{const d=document.querySelector('dialog[open]');if(d){d.close();return true}return false})()",r->{if(!"true".equals(r))moveTaskToBack(true);});}
    @Override protected void onDestroy(){if(picker!=null)picker.onReceiveValue(null);web.removeJavascriptInterface("AndroidFiles");web.destroy();super.onDestroy();}
}
