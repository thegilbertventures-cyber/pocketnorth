# PocketNorth

A private monthly budget for web and Android. This is a release candidate source package, **not a deployed service**. Local data/database tests pass. Live authentication, Plaid Sandbox, production bank access, and the updated Android APK still require configuration and end-to-end verification.

## What is included

- Responsive Home with clickable spending insights and optional AI review.
- Sign up/in, email confirmation/reset, password/email changes, authenticator enrollment and verification, multiple authenticators, sign-out across devices, account deletion.
- Per-user cloud data, realtime refresh, category editing, monthly targets, transaction review and export.
- ICCU CSV import and original Our Budget v1 JSON transaction migration. Stable bank IDs are deduplicated; no-ID files use normalized date/amount/description plus occurrence count. Distinct IDs and possible CSV/Plaid overlaps stay for review. Excluding a duplicate removes it from totals without destroying the record.
- Gas-station expenses **strictly above $30** go to the protected Fuel rule category. Exactly $30 and smaller amounts go to Gas Station. These categories can be renamed. Their automatic rule takes precedence over a remembered merchant rule; individual records can still be overridden.
- Plaid Hosted Link in an external browser, encrypted server-only tokens, cursor-based incremental sync, pending-to-posted reconciliation, reconnect and disconnect.
- Github Pages deployment workflow. Only the `web` directory is published.

Each login owns a separate budget. Sign into the same login across devices for the same data. Separate household logins sharing one budget are not implemented.

## Preview and verify locally

Requires Node 22+ and Python 3. Run `npm ci`, `npm test`, then `npm run build`. Serve the web directory with `python3 -m http.server 8080 --directory web` and open `http://localhost:8080/?demo`.

Preview data is fictional and temporary. The public config is intentionally blank. Original private CSVs, workbook contents, passwords, and Android signing keys are not included.

## 1. Supabase database and authentication

Use a dedicated Supabase project. Link it with the Supabase CLI, run `supabase db push` for the two migrations, and deploy with `supabase functions deploy pocketnorth-api`. Review migrations before applying to an existing project; they create new named tables and functions.

In Authentication settings:

1. Set Site URL to the final `https://YOUR-ACCOUNT.github.io/YOUR-REPO/` and add that exact callback URL plus `?recovery=1` to allowed redirects. A custom domain is supported; keep all config values consistent.
2. Enable email confirmation and TOTP MFA. Set password minimum length to 12, enable secure password change and secure email change, and enable leaked-password protection where your plan supports it.
3. Configure production SMTP. Supabase's default mail service is unsuitable for general production signup. Configure authentication rate limits and consider supported CAPTCHA before opening public registration.
4. Use a short access-token lifetime appropriate to your needs (for example 10 minutes). Signing out revokes refresh sessions; issued access tokens may remain valid until expiry. The local app clears data immediately.
5. Maintain a documented manual identity-verification process for users who lose all authenticators. There is no client-side MFA bypass or recovery-code feature in this version. Encourage a second verified authenticator.

MFA is enforced in database policies and functions and in the bank API, not only the interface. Anonymous users and password-only sessions cannot access financial tables. Owner-qualified foreign keys prevent cross-account reassignment. Sensitive token tables have no browser grants. Database owners and service-role administrators remain privileged; protect those accounts with MFA.

The app uses sessionStorage and PKCE. Email confirmation/password-reset links should be opened in the same browser context that requested them. Android users can complete email confirmation in a browser then sign into the app. For password reset, initiate and complete it in the web browser; authenticator verification is still required before accessing account data.

## 2. Plaid server configuration

Add these using **Supabase Edge Function secrets**, not Github repository variables, HTML, or chat:

| Secret | Value |
| --- | --- |
| `PLAID_CLIENT_ID` | Your Plaid client ID |
| `PLAID_SECRET` | Secret for the selected environment |
| `PLAID_ENV` | `sandbox` initially; `production` only after approval/testing |
| `TOKEN_ENCRYPTION_KEY` | Cryptographically random 32-byte key encoded as base64 |
| `SITE_URL` | Exact HTTPS site directory URL ending in `/` |
| `OPENAI_API_KEY` | Optional, for AI review |
| `OPENAI_MODEL` | Optional, a model your project can use with Chat Completions and JSON-object responses |

Supabase supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to hosted functions. Back up the encryption key securely; losing it requires reconnecting bank feeds. Rotation requires decrypting/re-encrypting existing token records before replacing the key. Tokens are stored as AES-GCM ciphertext. Do not enable request-body logging.

Enable Plaid Transactions and Hosted Link for the relevant environment. Complete Plaid's production/access requirements. HTTPS alone does not establish approval. ICCU availability depends on Plaid's institution coverage and your enabled products; confirm it in Link.

Start with Sandbox. Test connecting a bank, Finish connection, Sync transactions, reconnect and disconnect. The app obtains public tokens server-side from its own user-bound Link session; the browser cannot submit another user's access token.

Bank imports are **manual** in this release: tap Sync transactions. Supabase realtime keeps saved data aligned between devices, but it does not cause Plaid to poll the bank. Scheduled refresh and verified webhooks are not included. Initial bank history can take time; sync again later.

Supported financial currency: USD. Classification is conservative for unknown deposits/transfers. Plaid and CSV records have different IDs; compare flagged overlaps before excluding duplicates. Without stable CSV IDs, overlapping exports with differing occurrence counts can be ambiguous. Use consistent account selection and review flagged records.

## 3. Github Pages

Create or choose the repository, upload this package's source, and select **Github Actions** in Settings → Pages. Add these public repository variables:

- `SUPABASE_URL`: your project's HTTPS URL.
- `SUPABASE_PUBLISHABLE_KEY`: publishable key or legacy anon key, never service-role/secret key.
- `SITE_URL`: the Github Pages URL, ending in `/`.

Push to `main` or manually run the workflow. It runs the database/import tests, builds the SDK, writes public configuration, and publishes only `web`. Enable Enforce HTTPS. Protect the repository and deployment account with MFA and branch protection; someone who can change the shipped JavaScript can affect signed-in users.

Do not put transaction exports or signing keys in this repository. Github Pages is a static frontend; Supabase owns authentication, database access, and the secret-bearing bank API. The meta CSP limits scripts and connections. Github Pages does not support arbitrary response headers; for deployment-enforced CSP/frame-ancestors or other custom security headers, use a host that supports them.

## 4. Android

The `android` project uses the original package ID and version code 2. It loads the pinned HTTPS site, so published interface updates appear without rebuilding the APK. Native changes still require rebuilding. It requires an internet connection and does not provide offline editing.

Set `SITE_URL` in `android/gradle.properties` to the same final site URL. Open `android` in Android Studio, sync with Gradle 8.9, and build a signed release with the **original Our Budget signing key** from your private recovery archive. Never upload that key. Export an original v1 JSON backup before installing the update; the old local budget is not automatically uploaded. Import that backup after signing in.

No updated APK is supplied until a real site URL is available and the release can be tested. Do not replace the working old APK with a placeholder build. Verify file import/export, authenticator switching, hosted Plaid return, password reset via web, and data consistency on a physical device before release.

## AI and privacy

The default Home insights are computed locally from recorded data. Optional AI review requires explicit consent each time and sends monthly category names, category totals, targets, and review counts to OpenAI, not merchant names or bank credentials. Category names themselves may be sensitive. The backend validates output shape and allowed category references; suggestions can still be mistaken and need review. No external AI service is called in preview mode.

## Release checks still required

- Apply migrations to a test Supabase project; verify signup, email delivery, recovery and MFA with two separate users.
- Verify realtime updates on two devices and conflict handling for simultaneous edits.
- Complete Plaid Sandbox end-to-end and production access verification, including ICCU if available.
- Check account deletion with live Plaid disconnect failures/retries.
- Complete Android compilation/signing and physical-device verification using the final site URL.

This source has automated import and PostgreSQL policy tests. These tests do not certify the hosted configuration, Plaid service behavior, or Android build.
